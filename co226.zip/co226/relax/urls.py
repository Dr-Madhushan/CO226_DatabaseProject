from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('customer_gallery', views.customer_gallery, name='customer_gallery'),
    path('company_registration1', views.company_registration1, name='company_registration1'),
    path('signIn', views.signIn, name='signIn'),
    path('removeProduct', views.removeProduct, name='removeProduct'),
    path('disPage', views.disPage, name="disPage"),
    path('createProduct', views.createProduct, name='createProduct')
]
