from django.db import models

# Create your models here.
class Product:
    id : str
    name : str
    brand : str
    price : float
    img : str
    mfd_ctry : str

class Mycomp:
    name : str
    address : str
    email : str

class Company:
    def __init__(self, name, brc, email, password, type, hotline, address1, address2, city, province, zip):
        #self.id = id
        self.address1 = address1
        self.address2 = address2 
        self.brc = brc
        self.city = city 
        self.email = email
        self.hotline = hotline
        #self.managerId = managerId 
        self.name = name
        self.password = password 
        self.province = province
        self.type = type
        self.zip = zip


    id : str
    name : str
    brc : str
    email : str
    password : str
    type : str
    managerId : str
    hotline : str
    address1 : str
    address2 : str
    city : str
    province : str
    zip : int

class Employee:
    def __init__(self, fname, lname, email, password, jobType, mobile, nic):
        #self.companyId = companyId
        self.email = email
        self.fname = fname
        #self.id = id
        self.jobType = jobType
        self.lname = lname
        self.name = fname + ' ' + lname
        self.password = password
        self.nic = nic
        self.mobile = mobile
    

    id : str
    fname : str
    lname : str
    name : str
    companyId : str
    nic : str
    email : str
    mobile: str
    password : str
    jobType : int