from django.shortcuts import render
from mysql.connector import cursor
from .models import Company, Employee, Product, Mycomp
import mysql.connector as mc

db = mc.connect(host="localhost", user="root", passwd="0779485724", database='project')

# Create your views here.

user = 'guest'
passwd = ''

def index(request):
    return render(request, 'index.html')

def setUser(userID):
    user = userID
    return user

def signIn(request):
    global user, passwd
    user = setUser(request.POST.get('userid', user))
    passwd = request.POST.get('password', passwd)

    return disPage(request)

def logOut(request):
    global user, passwd
    user = 'guest'
    passwd = ''

def disPage(request):
    global user, passwd
    print(user)
    if user[:3] == 'DEM':
        query = "select * from product, Distributor_Employee where Distributor_Employee.CompanyID = Product.CompanyID and Distributor_Employee.UserID = '" + user + "'"
        getCompData = "select Name, Email from company where CompanyID = (select CompanyID from Distributor_Employee where UserID = '" + user + "')"
        passget = "select Password from Distributor_Employee where UserID = '" + user + "'"

        xcursor = db.cursor()
        xcursor.execute(query)
        myproducts = xcursor.fetchall()
        xcursor.execute(passget)
        passcheck = xcursor.fetchone()
        print(passcheck)
        if passwd != passcheck[0]:
            message = "invalid user id or password"
            return render(request, 'index.html', {'message' : message})
        
        products = []
        for product in myproducts:
            p = Product()
            p.id = product[1]
            p.name = product[2]
            p.brand = product[3]
            p.price = product[4]
            p.mfd_ctry = product[5]
            p.img = 'img/product.jpg'

            products.append(p)
        
        #xcursor = db.cursor()
        xcursor.execute(getCompData)
        mydetails = xcursor.fetchone()
        myCompany = Mycomp()
        myCompany.name = mydetails[0]
        myCompany.email = mydetails[1]

        return render(request, 'store_dis_control.html', {'products': products, 'company' : myCompany, 'user' : user})

    elif user[:3] == 'CEM':
        getCompData = "select Name, Email from company where CompanyID = (select CompanyID from Customer_Employee where UserID = '" + user + "')"
        passget = "select Password from Customer_Employee where UserID = '" + user + "'"

        xcursor = db.cursor()
        xcursor.execute(passget)
        passcheck = xcursor.fetchone()
        print(passcheck)
        if passwd != passcheck[0]:
            message = "invalid user id or password"
            return render(request, 'index.html', {'message' : message})
        
        xcursor.execute(getCompData)
        mydetails = xcursor.fetchone()
        myCompany = Mycomp()
        myCompany.name = mydetails[0]
        myCompany.email = mydetails[1]

        xcursor.execute('select * from product')
        fetched_products = xcursor.fetchall()
        print(user)
        products = []
        for product in fetched_products:
            p = Product()
            p.id = product[1]
            p.name = product[2]
            p.brand = product[3]
            p.price = product[4]
            p.mfd_ctry = product[5]
            p.img = 'img/product.jpg'
            
            products.append(p)
        
        return render(request, 'product_gallery_customer.html', {'products': products, 'user' : user, 'company' : myCompany})

    message = "invalid user id"
    return render(request, 'index.html', {'message' : message})

def customer_gallery(request):
    xcursor = db.cursor()
    xcursor.execute('select * from product')
    fetched_products = xcursor.fetchall()
    print(user)
    products = []
    for product in fetched_products:
        p = Product()
        p.id = product[1]
        p.name = product[2]
        p.brand = product[3]
        p.price = product[4]
        p.mfd_ctry = product[5]
        p.img = 'img/product.jpg'
        
        products.append(p)
    
    return render(request, 'product_gallery_customer.html', {'products': products})


def company_registration1(request):
    
    if request.method == 'POST':
        company = Company(request.POST['CompanyName'],request.POST['brcNo'],request.POST['email'], request.POST['password'],request.POST['companyType'], request.POST['hotline'], request.POST['address1'], request.POST['address2'], request.POST['city'], request.POST['province'], request.POST['zip'])
        
        manager = Employee(request.POST['fname'], request.POST['lname'], request.POST['email'], request.POST['password'], 1, request.POST['mobile'], request.POST['nicNo'])
        
        accountant = request.POST['acc1']
        purman = request.POST['pm1']
        supervisor = request.POST['sup1']
        
        xcursor = db.cursor()
        print(company.email)

        # sql queries
        query1 = "select * from Company where Email= '" + str(company.email) + "'"
        query2 = "select max(CompanyID) from Company where left(CompanyID,1) = 'D'"
        query3 = "select max(CompanyID) from Company where left(CompanyID,1) = 'C'"
            
        xcursor.execute("select * from Company")
        m = xcursor.fetchall()
            
        for i in m:
            print(i)

        if company.type == 'Distributor':
            xcursor.execute(query1)
            match = xcursor.fetchall()

            xcursor.execute(query2)
            idNum = xcursor.fetchall()
                
            company.id = 'D' + str(int(idNum[0][0][1:]) + 1)
                
            insert_into_company = "INSERT INTO Company(CompanyID, Name, BRC_No, Email, Password, Company_Type) VALUES ('" + company.id + "','" + company.name + "','" + company.brc + "','" + company.email + "','" + company.password + "','" + "2" + "')"
                
            manidcheck = "select max(UserID) from Distributor_Employee where left(UserID,3) = 'DEM'"
            xcursor.execute(manidcheck)
            man = xcursor.fetchall()
            manager.id = 'DEM' + str(int(man[0][0][3:]) + 1)
            insert_into_Demp = "INSERT INTO distributor_employee VALUES('" + manager.id + "', '" + company.id + "', '" + manager.name + "', '" + manager.nic + "', '" + manager.email + "', '" + manager.password + "', '1')"
            update_company = "UPDATE Company SET DistMGR = '" + manager.id + "' WHERE CompanyID = '" + company.id + "'"    
                
            print(insert_into_company)
            print(insert_into_Demp)

            print("existing ",match)
            if len(match) == 0:
                xcursor.execute(insert_into_company)
                xcursor.execute(insert_into_Demp)
                xcursor.execute(update_company)

                user = manager.id
                output = "Your account created! Your user ID is " + user
                db.commit()
                message = "Registration successful"
                print("Registration successful")
                return render(request, 'index.html', {'user':output})
            else:
                message = "Match found"
                print("Match found")
            
            # select max(CompanyID), Email, CustMGR, DistMGR from Company
            # if company.type == 'Distributor':
            message = "Something went wrong"
        elif company.type == 'Customer':
            xcursor.execute(query1)
            match = xcursor.fetchall()

            xcursor.execute(query3)
            idNum = xcursor.fetchall()
                
            company.id = 'C' + str(int(idNum[0][0][1:]) + 1)
                
            insert_into_company = "INSERT INTO Company(CompanyID, Name, BRC_No, Email, Password, Company_Type) VALUES ('" + company.id + "','" + company.name + "','" + company.brc + "','" + company.email + "','" + company.password + "','" + "1" + "')"
                
            manidcheck = "select max(UserID) from Customer_Employee where left(UserID,3) = 'CEM'"
            xcursor.execute(manidcheck)
            man = xcursor.fetchall()
            print
            manager.id = 'CEM' + str(int(man[0][0][3:]) + 1)
            insert_into_Cemp = "INSERT INTO Customer_employee(UserID, CompanyID, Name, NIC_No, Email, Password, JobType) VALUES('" + manager.id + "', '" + company.id + "', '" + manager.name + "', '" + manager.nic + "', '" + manager.email + "', '" + manager.password + "', '1')"
            update_company = "UPDATE Company SET CustMGR = '" + manager.id + "' WHERE CompanyID = '" + company.id + "'"    
                
            print(insert_into_company)
            print(insert_into_Cemp)

            print("existing ",match)
            if len(match) == 0:
                xcursor.execute(insert_into_company)
                print("company inserted")
                xcursor.execute(insert_into_Cemp)
                print("Manager inserted")
                xcursor.execute(update_company)
                print("Manager updated")

                user = manager.id
                output = "Your account created! Your user ID is " + user
                db.commit()
                message = "Registration successful"
                print("Registration successful")
                return render(request, 'index.html', {'user': output})
            else:
                message = "Match found"
                print("Match found")
            
            # select max(CompanyID), Email, CustMGR, DistMGR from Company
            # if company.type == 'Distributor':
        message = "Something went wrong"
        return render(request, 'SignUp_ComMan.html', {'message': message})
    else:
        return render(request, 'SignUp_ComMan.html')
        #print(fname,lname)

def createProduct(request):
    global user, passwd

    new = Product()
    new.brand = request.POST['ProductBrand']
    new.name = request.POST['ProductName']
    new.price = request.POST['Price']
    new.mfd_ctry = request.POST['Country']
    
    xcursor = db.cursor()
    Company = "D" + user[3:]
    getProductId = "select max(ProductID) from Product"
    xcursor.execute(getProductId)
    id = xcursor.fetchall()
    id = int(id[0][0][1:]) + 1
    new.id = "P" + str(id)

    createProductQuery = "insert into Product value ('" + Company + "', '" + new.id + "', '" + new.name + "', '" + new.brand + "', '" + new.price + "', '" + new.mfd_ctry + "', 1);"
    xcursor.execute(createProductQuery)
    db.commit()
    return disPage(request)


def removeProduct(request):
    global user, passwd
    print("remove")
    ycursor = db.cursor()
    if request.method == 'POST':
        print("post found")
        productID = request.POST['pid']
        check = "SELECT UserID FROM Distributor_Employee WHERE CompanyID = (SELECT CompanyID FROM Product WHERE ProductID = '" + productID + "') AND left(UserID,3) = 'DEM';"
        
        ycursor.execute(check)
        userid = ycursor.fetchone()

        print(check)
        print(productID[0], len(productID), user, userid[0])
        if productID[0] == 'P' and len(productID) == 3 and str(userid[0]) == user:
            print("running")
            removeQuery = "DELETE FROM Product WHERE ProductID = '" + productID + "';"
            print(removeQuery)
            #ycursor.execute(check)
            ycursor.execute(removeQuery)
            print("user name = ", user)
            db.commit()
    return disPage(request)                   
                               
    # INSERT INTO Product VALUES( "P01",  " Tomato sauce",  "Heinz",  "548597.00",  "Hong Kong",  TRUE);
                        