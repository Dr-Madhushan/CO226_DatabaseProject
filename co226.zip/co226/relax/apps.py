from django.apps import AppConfig


class RelaxConfig(AppConfig):
    name = 'relax'
